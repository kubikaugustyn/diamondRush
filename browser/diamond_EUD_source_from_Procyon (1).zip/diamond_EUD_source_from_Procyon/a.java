// 
// Decompiled by Procyon v0.5.36
// 

public interface a
{
    public static final int a;
    public static final int b;
    public static final int[] a;
    public static final int[] b = { 0, 10, 25 };
    public static final int[] c;
    public static final int[] d;
    public static final byte[][] a = { { -1, -1, 0, -1 }, { 1, -1, 3, -1 }, { 2, 2, -1, -1 }, { -1, 0, -1, 2 } };
    public static final int c = 240 - a.a - 10;
    public static final int d = a.a + 1;
    public static final int e = 310 - a.a + 6;
    public static final int f = a.a + 6;
    public static final int g = 69 - a.f;
    public static final int h = a.a + 4;
    public static final int i = a.g + a.f / 2;
    
    default static {
        b = (a = new h(0).a.getHeight());
        a = new int[] { 150, 400, 1000, 3000 };
        c = new int[] { -24, -23, 24, -23, 0, 23, 24, 23 };
        d = new int[] { -33, -54, 14, -54, -8, -8, 22, 2 };
    }
}
