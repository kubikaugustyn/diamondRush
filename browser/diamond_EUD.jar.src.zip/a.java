public interface a {
  public static final int a;
  
  public static final int b = a = (new h(0)).a.getHeight();
  
  public static final int[] a = new int[] { 150, 400, 1000, 3000 };
  
  public static final int[] b = new int[] { 0, 10, 25 };
  
  public static final int[] c = new int[] { -24, -23, 24, -23, 0, 23, 24, 23 };
  
  public static final int[] d = new int[] { -33, -54, 14, -54, -8, -8, 22, 2 };
  
  public static final byte[][] a = new byte[][] { { -1, -1, 0, -1 }, { 1, -1, 3, -1 }, { 2, 2, -1, -1 }, { -1, 0, -1, 2 } };
  
  public static final int c = 240 - a - 10;
  
  public static final int d = a + 1;
  
  public static final int e = 310 - a + 6;
  
  public static final int f = a + 6;
  
  public static final int g = 69 - f;
  
  public static final int h = a + 4;
  
  public static final int i = g + f / 2;
}


/* Location:              C:\Users\Radek Augustyn\Desktop\Nokia 6303i classic_2022-03-06\Settings\predefjava\predefgames\diamond_EUD.jar!\a.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */